<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Menurank extends Model
{
    //
}
